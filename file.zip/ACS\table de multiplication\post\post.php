<?php
/*
    for($i = 1 ; $i <= 10 ; $i++) {
        if(isset($_POST['check_' . $i .''])) {
            
            $y = $_POST['check_' . $i .''];

            echo 'Table de ' . $y .PHP_EOL;

            for($j = 0 ; $j <= 10 ; $j++) {
                echo $y . ' x ' . $j . ' = ' . $y * $j .PHP_EOL;
            }

            echo PHP_EOL;
        }
    }
*/
echo 'salut';
?>
