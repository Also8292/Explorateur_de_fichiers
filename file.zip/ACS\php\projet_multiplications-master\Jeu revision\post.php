<?php
session_start();

$tab[] = "";
for($i = 0 ; $i <= 10 ; $i++) { //cette boucle nous permet de parcourir les checkbox 
    if(isset($_POST['check_' . $i .''])) {//condition pour voir est-ce que le checkbox est selectionné ou pas
        $tab[$i] = $_POST['check_' . $i .''];
    }
    else {
        $tab[$i] = "unchecked";
    }
}

foreach($tab as $index => $table) {

    if($table != 'unchecked') {

        $nbre = rand(0, 10);
        $_SESSION['resultat'] = $nbre * $table;

        $resultat = $_SESSION['resultat'];

        ?>
        <h3>Combien vaut : <?= $table ?> x <?= $nbre ?></h3>
        
            <p><input type="text" id="input_response<?= $index ?>" placeholder="Votre réponse..." onblur="operation(<?= $resultat ?>, <?= $index ?>)" required>
                <div class="score_unit" id="result<?= $index ?>"></div>
            </p>        
        <br>
        <?php     
    }
}
    ?>
        <p>
            <input type="submit" value="Valider" onclick="">
            <p>Votre score est de : <span id="score"></span></p>
        </p>
    <script>
        function operation(resultat, index) {
            var input_response = document.querySelector('#input_response' + index).value;
            var resultSpan = document.querySelector('#result' + index);

            if(input_response != "") {
                if(input_response == resultat) {
                    resultSpan.innerHTML = 10;
                    score = 10;
                }
                else {
                    resultSpan.innerHTML = 0;
                    score = 0;
                }
            }
            document.querySelector('#score').innerHTML += score;
        }
    
    </script>
    <?php 
?>