<!DOCTYPE html>
<html lang="fr">
<head>
	<title>Atelier PHP - Mode révision</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link rel="stylesheet" href="css/style.css">
</head>
<body>

<header>
	<h1>Atelier PHP - Étape 2</h1>
	<p>Afficher les tables de multiplication</p>
</header>

<form method="post" action="post/post.php">
	<section class="contentbox">
		<div class="maincontent">
			
			<div class="fields">
				<h3>Merci de sélectionner les tables que vous voulez consulter:</h3>
				<label><input type="checkbox" name="check_1" class="checkbox" value="1"/> Table de 1</label>
				<label><input type="checkbox" name="check_2" class="checkbox" value="2"/> Table de 2</label>
				<label><input type="checkbox" name="check_3" class="checkbox" value="3"/> Table de 3</label>
				<label><input type="checkbox" name="check_4" class="checkbox" value="4"/> Table de 4</label>
				<label><input type="checkbox" name="check_5" class="checkbox" value="5"/> Table de 5</label>
				<label><input type="checkbox" name="check_6" class="checkbox" value="6"/> Table de 6</label>
				<label><input type="checkbox" name="check_7" class="checkbox" value="7"/> Table de 7</label>
				<label><input type="checkbox" name="check_8" class="checkbox" value="8"/> Table de 8</label>
				<label><input type="checkbox" name="check_9" class="checkbox" value="9"/> Table de 9</label>
				<label><input type="checkbox" name="check_10" class="checkbox" value="10"/> Table de 10</label>
				<input type="text" name="test">
			</div>

			<div class="action_buttons">
				<div class="button"><input type="submit" value="Voir les tables" id="valider"></div>
				<div class="button"><input type="reset" value="Annuler" id="annuler"></div>
			</div>
		
		</div>
		<div id="resultat"></div>	 
	</section>
</form>
<script src="js/script.js"></script>
</body>
</html>