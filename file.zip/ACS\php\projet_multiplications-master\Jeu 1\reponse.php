<?php

    $resultat = $_GET['resultat'];
    $reponse = $_POST['reponse'];

    if($resultat == $reponse) {
        echo 'Félicitation';
        echo '<a href="index.html">rejouer</a>';
    }
    else {
        echo 'Faux';
        echo 'La bonne réponse est : ' . $resultat;
        echo '<a href="index.html">Retour à l\'accueil</a>';
    }

    

?>