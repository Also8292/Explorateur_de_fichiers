var httpRequest = new XMLHttpRequest();

var btnValider = document.querySelector('#valider');
var btnAnnuler = document.querySelector('#annuler');

btnValider.addEventListener('click', function(e) {
        
    httpRequest.onreadystatechange = function() {
        if(httpRequest.responseText != "") {
            document.querySelector('#resultat').innerHTML = httpRequest.responseText;
        }
    }
    httpRequest.open('GET', 'post/post.php', true);

    httpRequest.send();

    e.preventDefault();
});

btnAnnuler.addEventListener('click', function() {
    document.querySelector('#resultat').innerText = "";
});

