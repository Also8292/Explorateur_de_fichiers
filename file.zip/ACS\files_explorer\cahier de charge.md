FONCTIONNALITES
	1 Affichage les dossiers et les fichiers
    2 Se déplacer à l'interieur d'un dossier
	3 Création d'un nouveau dossier
	4 Suppréssion d'un dossier ou d'un fichier
	5 Rennomer un dossier ou un fichier
	6 Remonter dans le dossier parent
	7 Copier/Déplacer/Coller un fichier
	8 Télécharger un fichier ou un dossier
	9 Uploader un dossier ou un fichier
	
Bonus
	10 Interface de connexion
    11 Afficher le contenu d'un fichier
    12 Possibilité d'éditer un fichier avec sauvegarde des modofication